package lecho.lib.hellocharts.model;

public enum ValueShape {
	CIRCLE, SQUARE,BITMAP,JSTYLE,JSTYLE_PLUS
}
