package com.jstyle.blesdk2025.model;

public enum AutoMode {
    AutoHeartRate, AutoSpo2,AutoTemp,AutoHrv
}
